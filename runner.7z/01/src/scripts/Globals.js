export const Globals = {
    resources: {}
};